function CoffeeMake(drink, firm) {
  this.drink = drink
  this.firm = firm
}

CoffeeMake.prototype.on = function () {
  console.log('Start');
}
CoffeeMake.prototype.off = function () {
  console.log('Stop');
}



function DripCoffeeMachine(drink, firm, drip) {
  CoffeeMake.call(this, drink, firm)
  this.drip = drip
}
DripCoffeeMachine.prototype = Object.create(CoffeeMake.prototype)
DripCoffeeMachine.prototype.constuctor = DripCoffeeMachine

DripCoffeeMachine.prototype.drippingCoffee = function () {
  console.log(`functionality: ${this.drip}`);
}
let emp1 = new DripCoffeeMachine('Coffee', 'Philips', 'drip');
console.log(emp1)
emp1.on()
emp1.off()
emp1.drippingCoffee()

function CornishСoffeeMachine(drink, firm, horn) {
  CoffeeMake.call(this, drink, firm)
  this.horn = horn
}
CornishСoffeeMachine.prototype = Object.create(CoffeeMake.prototype)
CornishСoffeeMachine.prototype.constuctor = CornishСoffeeMachine

CornishСoffeeMachine.prototype.horningCoffee = function () {
  console.log(`functionality: ${this.horn}`)
}
let emp2 = new CornishСoffeeMachine('Coffee', 'Philips', 'horn');
console.log(emp2)

emp2.on()
emp2.off()
emp2.horningCoffee()


function CoffeeMachine(drink, firm, coffeeBeans ) {
  CoffeeMake.call(this, drink, firm)
  this.coffeeBeans = coffeeBeans
}
CoffeeMachine.prototype = Object.create(CoffeeMake.prototype)
CoffeeMachine.prototype.constuctor = CoffeeMachine

CoffeeMachine.prototype.typeBeans = function () {
  console.log(`coffeeBeans: ${this.coffeeBeans}`)
}

let emp3 = new CoffeeMachine('Coffee', 'Philips', 'Arabica');
console.log(emp3)

emp3.on()
emp3.off()
emp3.typeBeans()